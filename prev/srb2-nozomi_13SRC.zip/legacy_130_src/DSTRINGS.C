// Emacs style mode select   -*- C++ -*- 
//-----------------------------------------------------------------------------
//
// $Id: dstrings.c,v 1.5 2000/04/20 21:49:53 hurdler Exp $
//
// Copyright (C) 1993-1996 by id Software, Inc.
// Portions Copyright (C) 1998-2000 by DooM Legacy Team.
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
//
// $Log: dstrings.c,v $
// Revision 1.5  2000/04/20 21:49:53  hurdler
// fix a bug in dehacked
//
// Revision 1.4  2000/04/16 18:38:07  bpereira
// no message
//
// Revision 1.3  2000/04/04 00:32:45  stroggonmeth
// Initial Boom compatability plus few misc changes all around.
//
// Revision 1.2  2000/02/27 00:42:10  hurdler
// fix CR+LF problem
//
// Revision 1.1.1.1  2000/02/22 20:32:32  hurdler
// Initial import into CVS (v1.29 pr3)
//
//
// DESCRIPTION:
//      Globally defined strings.
// 
//-----------------------------------------------------------------------------

#include "dstrings.h"

char *text[NUMTEXT] = {
   "Development mode ON.\n",
   "CD-ROM Version: default.cfg from c:\\doomdata\n",
   "press a key.",
   "press y or n.",
   "only the server can do a load net game!\n\npress a key.",
   "you can't quickload during a netgame!\n\npress a key.",
   "you haven't picked a quicksave slot yet!\n\npress a key.",
   "you can't save if you aren't playing!\n\npress a key.",
   "quicksave over your game named\n\n'%s'?\n\npress y or n.",
   "do you want to quickload the game named\n\n'%s'?\n\npress y or n.",
   "you can't start a new game\n""while in a network game.\n\n",
   "are you sure? this skill level\nisn't even remotely fair.\n\npress y or n.",
   "this is the shareware version of doom.\n\nyou need to order the entire trilogy.\n\npress a key.",
   "Messages OFF",
   "Messages ON",
   "you can't end a netgame!\n\npress a key.",
   "are you sure you want to end the game?\n\npress y or n.",

   "%s\n\n(press y to quit to dos.)",

   "High detail",
   "Low detail",
   "Gamma correction OFF",
   "Gamma correction level 1",
   "Gamma correction level 2",
   "Gamma correction level 3",
   "Gamma correction level 4",
   "empty slot",
   "Picked up the armor.",
   "Picked up the MegaArmor!",
   "Picked up a health bonus.",
   "Picked up an armor bonus.",
   "Picked up a stimpack.",
   "Picked up a medikit that you REALLY need!",
   "Picked up a medikit.",
   "Supercharge!",

   "Picked up a blue keycard.",
   "Picked up a yellow keycard.",
   "Picked up a red keycard.",
   "Picked up a blue skull key.",
   "Picked up a yellow skull key.",
   "Picked up a red skull key.",

   "Invulnerability!",
   "Berserk!",
   "Partial Invisibility",
   "Radiation Shielding Suit",
   "Computer Area Map",
   "Light Amplification Visor",
   "MegaSphere!",

   "Picked up a clip.",
   "Picked up a box of bullets.",
   "Picked up a rocket.",
   "Picked up a box of rockets.",
   "Picked up an energy cell.",
   "Picked up an energy cell pack.",
   "Picked up 4 shotgun shells.",
   "Picked up a box of shotgun shells.",
   "Picked up a backpack full of ammo!",

   "You got the BFG9000!  Oh, yes.",
   "You got the chaingun!",
   "A chainsaw!  Find some meat!",
   "You got the rocket launcher!",
   "You got the plasma gun!",
   "You got the shotgun!",
   "You got the super shotgun!",

   "You need a blue key to activate this object",
   "You need a red key to activate this object",
   "You need a yellow key to activate this object",
   "You need a blue key to open this door",
   "You need a red key to open this door",
   "You need a yellow key to open this door",

   "game saved.",
   "[Message unsent]",

   "E1M1: Hangar",
   "E1M2: Nuclear Plant",
   "E1M3: Toxin Refinery",
   "E1M4: Command Control",
   "E1M5: Phobos Lab",
   "E1M6: Central Processing",
   "E1M7: Computer Station",
   "E1M8: Phobos Anomaly",
   "E1M9: Military Base",

   "E2M1: Deimos Anomaly",
   "E2M2: Containment Area",
   "E2M3: Refinery",
   "E2M4: Deimos Lab",
   "E2M5: Command Center",
   "E2M6: Halls of the Damned",
   "E2M7: Spawning Vats",
   "E2M8: Tower of Babel",
   "E2M9: Fortress of Mystery",

   "E3M1: Hell Keep",
   "E3M2: Slough of Despair",
   "E3M3: Pandemonium",
   "E3M4: House of Pain",
   "E3M5: Unholy Cathedral",
   "E3M6: Mt. Erebus",
   "E3M7: Limbo",
   "E3M8: Dis",
   "E3M9: Warrens",

   "E4M1: Hell Beneath",
   "E4M2: Perfect Hatred",
   "E4M3: Sever The Wicked",
   "E4M4: Unruly Evil",
   "E4M5: They Will Repent",
   "E4M6: Against Thee Wickedly",
   "E4M7: And Hell Followed",
   "E4M8: Unto The Cruel",
   "E4M9: Fear",
   "Greenflower Zone Act 1", // Changed by Tails: 9-14-99
   "Greenflower Zone Act 2", // Changed by Tails: 9-14-99
   "Greenflower Zone Act 3", // Changed by Tails: 9-14-99
   "Techno Hill Zone Act 1", // Changed by Tails: 9-14-99
   "Techno Hill Zone Act 2", // Changed by Tails: 9-14-99
   "Techno Hill Zone Act 3", // Changed by Tails: 9-14-99
   "Deep Sea Zone Act 1", // Changed by Tails: 9-14-99
   "Deep Sea Zone Act 2", // Changed by Tails: 9-14-99
   "Deep Sea Zone Act 3", // Changed by Tails: 9-14-99
   "Mine Maze Zone Act 1", // Changed by Tails: 9-14-99
   "Mine Maze Zone Act 2", // Changed by Tails: 9-14-99

   "Mine Maze Zone Act 3", // Changed by Tails: 9-14-99
   "Rocky Mountain Zone Act 1", // Changed by Tails: 9-14-99
   "Rocky Mountain Zone Act 2", // Changed by Tails: 9-14-99
   "Rocky Mountain Zone Act 3", // Changed by Tails: 9-14-99
   "Red Volcano Zone Act 1", // Changed by Tails: 9-14-99
   "Red Volcano Zone Act 2", // Changed by Tails: 9-14-99
   "Red Volcano Zone Act 3", // Changed by Tails: 9-14-99
   "Dark City Zone Act 1", // Changed by Tails: 9-14-99
   "Dark City Zone Act 2", // Changed by Tails: 9-14-99

   "Dark City Zone Act 3", // Changed by Tails: 9-14-99
   "Doomship Zone Act 1", // Changed by Tails: 9-14-99
   "Doomship Zone Act 2", // Changed by Tails: 9-14-99
   "Doomship Zone Act 3", // Changed by Tails: 9-14-99
   "Robotnirock Zone Act 1", // Changed by Tails: 9-14-99
   "Robotnirock Zone Act 2", // Changed by Tails: 9-14-99
   "Robotnirock Zone Act 3", // Changed by Tails: 9-14-99
   "The Final Fight Zone!", // Changed by Tails: 9-14-99
   "Wood Zone", // Changed by Tails: 9-14-99
   "Dust Hill Zone", // Changed by Tails: 9-14-99

   "Speed Highway at Dawn", // Changed by Tails: 9-14-99
   "Hidden Palace Zone", // Changed by Tails: 9-14-99

   "level 1: congo",
   "level 2: well of souls",
   "level 3: aztec",
   "level 4: caged",
   "level 5: ghost town",
   "level 6: baron's lair",
   "level 7: caughtyard",
   "level 8: realm",
   "level 9: abattoire",
   "level 10: onslaught",
   "level 11: hunted",

   "level 12: speed",
   "level 13: the crypt",
   "level 14: genesis",
   "level 15: the twilight",
   "level 16: the omen",
   "level 17: compound",
   "level 18: neurosphere",
   "level 19: nme",
   "level 20: the death domain",

   "level 21: slayer",
   "level 22: impossible mission",
   "level 23: tombstone",
   "level 24: the final frontier",
   "level 25: the temple of darkness",
   "level 26: bunker",
   "level 27: anti-christ",
   "level 28: the sewers",
   "level 29: odyssey of noises",
   "level 30: the gateway of hell",

   "level 31: cyberden",
   "level 32: go 2 it",

   "level 1: system control",
   "level 2: human bbq",
   "level 3: power control",
   "level 4: wormhole",
   "level 5: hanger",
   "level 6: open season",
   "level 7: prison",
   "level 8: metal",
   "level 9: stronghold",
   "level 10: redemption",
   "level 11: storage facility",

   "level 12: crater",
   "level 13: nukage processing",
   "level 14: steel works",
   "level 15: dead zone",
   "level 16: deepest reaches",
   "level 17: processing area",
   "level 18: mill",
   "level 19: shipping/respawning",
   "level 20: central processing",

   "level 21: administration center",
   "level 22: habitat",
   "level 23: lunar mining project",
   "level 24: quarry",
   "level 25: baron's den",
   "level 26: ballistyx",
   "level 27: mount pain",
   "level 28: heck",
   "level 29: river styx",
   "level 30: last call",

   "level 31: pharaoh",
   "level 32: caribbean",
   "I'm ready to kick ro-butt!", // Changed by Tails: 9-14-99
   "I'm OK.",
   "I'm not looking too good!",
   "Help!",
   "You stink!", // Changed by Tails: 9-14-99
   "Next time I'll win!", // Changed by Tails: 9-14-99
   "Come here!",
   "I'll take care of it.",
   "Yes",
   "No",

   "You mumble to yourself",
   "Who's there?",
   "You scare yourself",
   "You start to rave",
   "You've lost it...",

   "[Message Sent]",
   "Follow Mode ON",
   "Follow Mode OFF",

   "Grid ON",
   "Grid OFF",
   "Marked Spot",
   "All Marks Cleared",

   "Music Change",
   "IMPOSSIBLE SELECTION, you stupid-head!", // Changed by Tails: 9-14-99
   "Wuss Mode On", // Tails 05-10-2000
   "Wuss Mode Off", // Tails 05-10-2000

   "Very Happy Ammo Added",
   "Ammo (no keys) Added",

   "No Clipping Mode ON",
   "No Clipping Mode OFF",

   "inVuln, Str, Inviso, Rad, Allmap, or Lite-amp",
   "Power-up Toggled",

   "... doesn't suck - GM",
   "Changing Level...",

   "Once you beat the big badasses and\n"\
   "clean out the moon base you're supposed\n"\
   "to win, aren't you? Aren't you? Where's\n"\
   "your fat reward and ticket home? What\n"\
   "the hell is this? It's not supposed to\n"\
   "end this way!\n"\
   "\n" \
   "It stinks like rotten meat, but looks\n"\
   "like the lost Deimos base.  Looks like\n"\
   "you're stuck on The Shores of Hell.\n"\
   "The only way out is through.\n"\
   "\n"\
   "To continue the DOOM experience, play\n"\
   "The Shores of Hell and its amazing\n"\
   "sequel, Inferno!\n",

   "You've done it! The hideous cyber-\n"\
   "demon lord that ruled the lost Deimos\n"\
   "moon base has been slain and you\n"\
   "are triumphant! But ... where are\n"\
   "you? You clamber to the edge of the\n"\
   "moon and look down to see the awful\n"\
   "truth.\n" \
   "\n"\
   "Deimos floats above Hell itself!\n"\
   "You've never heard of anyone escaping\n"\
   "from Hell, but you'll make the bastards\n"\
   "sorry they ever heard of you! Quickly,\n"\
   "you rappel down to  the surface of\n"\
   "Hell.\n"\
   "\n" \
   "Now, it's on to the final chapter of\n"\
   "DOOM! -- Inferno.",

   "The loathsome spiderdemon that\n"\
   "masterminded the invasion of the moon\n"\
   "bases and caused so much death has had\n"\
   "its ass kicked for all time.\n"\
   "\n"\
   "A hidden doorway opens and you enter.\n"\
   "You've proven too tough for Hell to\n"\
   "contain, and now Hell at last plays\n"\
   "fair -- for you emerge from the door\n"\
   "to see the green fields of Earth!\n"\
   "Home at last.\n" \
   "\n"\
   "You wonder what's been happening on\n"\
   "Earth while you were battling evil\n"\
   "unleashed. It's good that no Hell-\n"\
   "spawn could have come through that\n"\
   "door with you ...",

   "the spider mastermind must have sent forth\n"
   "its legions of hellspawn before your\n"\
   "final confrontation with that terrible\n"\
   "beast from hell.  but you stepped forward\n"\
   "and brought forth eternal damnation and\n"\
   "suffering upon the horde as a true hero\n"\
   "would in the face of something so evil.\n"\
   "\n"\
   "besides, someone was gonna pay for what\n"\
   "happened to daisy, your pet rabbit.\n"\
   "\n"\
   "but now, you see spread before you more\n"\
   "potential pain and gibbitude as a nation\n"\
   "of demons run amok among our cities.\n"\
   "\n"\
   "next stop, hell on earth!",

   "Oh no! Rudolph's stolen Santa's suit and\n"\
   "has hidden all the pieces! Can you recover\n"\
   "the missing garments? Use the indicators\n"\
   "at the bottom of the screen to help you.\n"\
   "Make sure to return the clothes back to\n"\
   "Santa once you've found them all!\n",

   "        It's been a long time,\n"\
   "        SONIC. Robots are running\n"\
   "        rampant once again... take\n"\
   "        this SNOWBALL BUSTER. It\n"\
   "will enable you to charge and\n"\
   "fire snowballs at the enemy by\n"\
   "using the 'FIRE' key... You can\n"\
   "do it, SONIC!",

   "I can't be bothered to eliminate these!\n",

   "THE HORRENDOUS VISAGE OF THE BIGGEST\n"\
   "DEMON YOU'VE EVER SEEN CRUMBLES BEFORE\n"\
   "YOU, AFTER YOU PUMP YOUR ROCKETS INTO\n"\
   "HIS EXPOSED BRAIN. THE MONSTER SHRIVELS\n"\
   "UP AND DIES, ITS THRASHING LIMBS\n"\
   "DEVASTATING UNTOLD MILES OF HELL'S\n"\
   "SURFACE.\n"\
   "\n"\
   "YOU'VE DONE IT. THE INVASION IS OVER.\n"\
   "EARTH IS SAVED. HELL IS A WRECK. YOU\n"\
   "WONDER WHERE BAD FOLKS WILL GO WHEN THEY\n"\
   "DIE, NOW. WIPING THE SWEAT FROM YOUR\n"\
   "FOREHEAD YOU BEGIN THE LONG TREK BACK\n"\
   "HOME. REBUILDING EARTH OUGHT TO BE A\n"\
   "LOT MORE FUN THAN RUINING IT WAS.\n",

   "CONGRATULATIONS, YOU'VE FOUND THE SECRET\n"\
   "LEVEL! LOOKS LIKE IT'S BEEN BUILT BY\n"\
   "HUMANS, RATHER THAN DEMONS. YOU WONDER\n"\
   "WHO THE INMATES OF THIS CORNER OF HELL\n"\
   "WILL BE.",

   "CONGRATULATIONS, YOU'VE FOUND THE\n"\
   "SUPER SECRET LEVEL!  YOU'D BETTER\n"\
   "BLAZE THROUGH THIS ONE!\n",


   "You've fought your way out of the infested\n"\
   "experimental labs.   It seems that UAC has\n"\
   "once again gulped it down.  With their\n"\
   "high turnover, it must be hard for poor\n"\
   "old UAC to buy corporate health insurance\n"\
   "nowadays..\n"\
   "\n"\
   "Ahead lies the military complex, now\n"\
   "swarming with diseased horrors hot to get\n"\
   "their teeth into you. With luck, the\n"\
   "complex still has some warlike ordnance\n"\
   "laying around.",


   "You hear the grinding of heavy machinery\n"\
   "ahead.  You sure hope they're not stamping\n"\
   "out new hellspawn, but you're ready to\n"\
   "ream out a whole herd if you have to.\n"\
   "They might be planning a blood feast, but\n"\
   "you feel about as mean as two thousand\n"\
   "maniacs packed into one mad killer.\n"\
   "\n"\
   "You don't plan to go down easy.",


   "The vista opening ahead looks real damn\n"\
   "familiar. Smells familiar, too -- like\n"\
   "fried excrement. You didn't like this\n"\
   "place before, and you sure as hell ain't\n"\
   "planning to like it now. The more you\n"\
   "brood on it, the madder you get.\n"\
   "Hefting your gun, an evil grin trickles\n"\
   "onto your face. Time to take some names.",

   "Suddenly, all is silent, from one horizon\n"\
   "to the other. The agonizing echo of Hell\n"\
   "fades away, the nightmare sky turns to\n"\
   "blue, the heaps of monster corpses start \n"\
   "to evaporate along with the evil stench \n"\
   "that filled the air. Jeeze, maybe you've\n"\
   "done it. Have you really won?\n"\
   "\n"\
   "Something rumbles in the distance.\n"\
   "A blue light begins to glow inside the\n"\
   "ruined skull of the demon-spitter.",


   "What now? Looks totally different. Kind\n"\
   "of like King Tut's condo. Well,\n"\
   "whatever's here can't be any worse\n"\
   "than usual. Can it?  Or maybe it's best\n"\
   "to let sleeping gods lie..",

   "Time for a vacation. You've burst the\n"\
   "bowels of hell and by golly you're ready\n"\
   "for a break. You mutter to yourself,\n"\
   "Maybe someone else can kick Hell's ass\n"\
   "next time around. Ahead lies a quiet town,\n"\
   "with peaceful flowing water, quaint\n"\
   "buildings, and presumably no Hellspawn.\n"\
   "\n"\
   "As you step off the transport, you hear\n"\
   "the stomp of a cyberdemon's iron shoe.",

   "ZOMBIEMAN",
   "SHOTGUN GUY",
   "HEAVY WEAPON DUDE",
   "IMP",
   "DEMON",
   "LOST SOUL",
   "CACODEMON",
   "HELL KNIGHT",
   "BARON OF HELL",
   "ARACHNOTRON",
   "PAIN ELEMENTAL",
   "REVENANT",
   "MANCUBUS",
   "ARCH-VILE",
   "THE SPIDER MASTERMIND",
   "THE CYBERDEMON",
   "OUR HERO",

  // DOOM1
  "Eggman's tied explosives\nto your girlfriend, and\nwill activate them if\nyou press the 'Y' key!\nPress 'N' to save her!", // Changed by Tails: 9-14-99
  "What would Tails say if\nhe saw you quitting the game?", // Changed by Tails: 9-14-99
  "Hey!\nWhere do ya think you're goin'?", // Changed by Tails: 9-14-99
  "Forget your studies!\nPlay some more!", // Changed by Tails: 9-14-99
  "You're trying to say you\nlike Sonic Adventure better than\nthis, right?", // Changed by Tails: 9-14-99
  "don't leave yet -- there's a\nsuper emerald around that corner!", // Changed by Tails: 9-14-99
  "You'd rather work than play?", // Changed by Tails: 9-14-99
  "go ahead and leave. see if i care...\n*sniffle*", // Changed by Tails: 9-14-99

  // QuitDOOM II messages
  "If you leave now,\nEggman will take over the world!", // Changed by Tails: 9-14-99
  "Don't quit!\nThere are animals\nto save!", // Changed by Tails: 9-14-99
  "Aw c'mon, just bop\na few more robots!", // Changed by Tails: 9-14-99
  "Just because you can't\nget that Chaos Emerald...", // Changed by Tails: 9-14-99
  "If you leave, i'll use\nmy spin attack on you!", // Changed by Tails: 9-14-99
  "Don't go!\nYou might find the hidden\nlevels!", // Changed by Tails: 9-14-99
  "Hit the 'N' key sonic!\nThe 'N' key!", // Changed by Tails: 9-14-99

  "FLOOR4_8",
  "SFLR6_1",
  "MFLR8_4",
  "MFLR8_3",
  "SLIME16",
  "RROCK14",
  "RROCK07",
  "RROCK17",
  "RROCK13",
  "RROCK19",

  "CREDIT",
  "HELP2",
  "VICTORY2",
  "ENDPIC",

  "===========================================================================\n"
  "                       Sonic Robo Blast II!\n"                                  // Changed by Tails: 9-14-99
  "                       by Sonic Team Junior\n"                                  // Changed by Tails: 9-14-99
  "                      http://stjr.cjb.net\n"                              // Changed by Tails: 9-14-99
  "      This is a modified version. Go to our site for the original.\n"           // Changed by Tails: 9-14-99
  "===========================================================================\n",

  "===========================================================================\n" \
  "                                Shareware!\n"                                  \
  "===========================================================================\n",

  "===========================================================================\n"
  "                   We hope you enjoy this game as\n"                            // Changed by Tails: 9-14-99
  "                     much as we did making it!\n"                               // Changed by Tails: 9-14-99
  "===========================================================================\n",

  "Austin Virtual Gaming: Levels will end after 20 minutes\n",
  "M_LoadDefaults: Load system defaults.\n",
  "Z_Init: Init zone memory allocation daemon. \n",
  "W_Init: Init WADfiles.\n",
  "M_Init: Init miscellaneous info.\n",
  "R_Init: Init DOOM refresh daemon - ",
  "\nP_Init: Init Playloop state.\n",
  "I_Init: Setting up machine state.\n",
  "D_CheckNetGame: Checking network game status.\n",
  "S_Init: Setting up sound.\n",
  "HU_Init: Setting up heads up display.\n",
  "ST_Init: Init status bar.\n",
  "External statistics registered.\n",

  "srb2.srb",
  "doomu.wad",
  "doom.wad",
  "doom1.wad",

  "c:\\doomdata",                         //UNUSED
  "c:/doomdata/default.cfg",              //UNUSED
  "c:\\doomdata\\"SAVEGAMENAME"%c.ssg",   //UNUSED // Tails 06-10-2001
  SAVEGAMENAME"%c.ssg",                   //UNUSED // Tails 06-10-2001
  "c:\\doomdata\\"SAVEGAMENAME"%d.ssg", // Tails 06-10-2001
  SAVEGAMENAME"%d.ssg", // Tails 06-10-2001

  //SoM: 3/9/2000: Boom generic key messages:
  "You need a blue card to open this door",
  "You need a red card to open this door",
  "You need a yellow card to open this door",
  "You need a blue skull to open this door",
  "You need a red skull to open this door",
  "You need a yellow skull to open this door",
  "Any key will open this door",
  "You need all three keys to open this door",
  "You need all six keys to open this door",

  //BP: here is special dehacked handling, include centring and version

  "Sonic Robo Blast 2: V0.65", // Changed by Tails: 9-14-99
  "The Ultimate DOOM Startup",
  "DOOM Registered Startup",
  "DOOM Shareware Startup",

};

char savegamename[256];
